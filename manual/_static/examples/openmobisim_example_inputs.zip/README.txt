Example inputs for openmobisim 0.1.0, made from its toy network.

gmns/          the network as GMNS (road/, bike/, walk/): ms.network_read_gmns("gmns")
trips.csv      40 trips on it:                       ms.demand_read_trips("trips.csv")
classes.csv    four traveller classes:               ms.demand_read_classes("classes.csv")
zones.csv      three zones:                          ms.demand_read_zones("zones.csv")
od.csv         a matrix between them:                ms.demand_read_od("od.csv")

Every column is described in the manual's Input files page.
